A Pen created at CodePen.io. You can find this one at http://codepen.io/giana/pen/PqVbRr.

 Fixed element appears to change color when entering different sections. Uses duplicated elements for every section.

Now with blend-mode magic for added effect.

Inspired by [Marco Fugaro](http://codepen.io/marco_fugaro/)'s Pen [Changing color when hover another section](http://codepen.io/marco_fugaro/pen/MwBWwW/).