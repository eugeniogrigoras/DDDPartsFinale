<?php
error_reporting(0);
$res=$_REQUEST["residenza"];
$cogn=$_REQUEST["cogn"];
$nome=$_REQUEST["nome"];
 

$conn=mysql_connect("localhost","root","") or
   die("Errore di connessione a Mysql");

mysql_select_db("banca5d") or die ("Errore di
                        connessione al Database");

$comando="select * from clienti where FKCitta='$res' ";
 
if($cogn)
   $comando=$comando."and Cognome like '%$cogn%' ";
if($nome)
   $comando=$comando."and Nome like '%$nome%'";
 

 
	$risultato=mysql_query($comando);
 
	if ($risultato){
		echo "<table border='2'>";
		echo "<tr>";
		echo "<td> Cognome</td>";
		echo "<td> Nome </td>";
		echo "<td> </td>";
		echo "<td> </td>";
		echo "</tr>";

	while ($dati=mysql_fetch_assoc($risultato))
	{
	 	echo "<tr>";
	    echo "<td>$dati[Cognome] </td>";
	    echo "<td>$dati[Cognome] </td>";
	    echo "<td> <a href='cancellacliente.php?idcl=$dati[IDCliente]'> Cancella </a></td>";
	    echo "<td> <a href='modificacliente.php?idcl=$dati[IDCliente]'> Modifica </a></td>";

	    echo "</tr>";
	}

echo "</table>";
}
else
echo "nessun risultato per questa Query";


mysql_close($conn);  
?>