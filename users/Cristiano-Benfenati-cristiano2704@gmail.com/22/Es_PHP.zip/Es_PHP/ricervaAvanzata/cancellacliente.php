<?php

$idcliente=$_REQUEST["idcl"];

$conn=mysql_connect("localhost","root","") or
   die("Errore di connessione a Mysql");

mysql_select_db("banca5d") or die ("Errore di
                        connessione al Database");

$comando="delete from clienti where IDCliente='$idcliente'";

if (mysql_query($comando))
	echo "cliente canc";
else
	echo "sgnorpz";

mysql_close($conn);  
?>