<html>
<head>
    <title>Page Title</title>
</head>

<body>
    <h1> RICERCA AVANZATA </h1>
    <form action="ericercaavanzata.php" name="fins" method="get">
        CITTA DI RESIDENZA
        <select name="residenza">
            <?php
                $conn=mysql_connect("localhost","root","");
                mysql_select_db("banca5d");
                $comando="select * from citta";
                $risultato=mysql_query($comando);
                while ($dati=mysql_fetch_assoc($risultato)) 
                    {
                    echo"<option value='$dati[IDCitta]'>$dati[NomeCitta]</option>";
                }
                mysql_close();
            ?>
        </select>
         COGNOME <input type="text" name="cogn" value="" />
         NOME <input type="text" name="nome" value="" />    
        <input type="submit" name="binvia" value="Conferma">
    </form>
        </body>
</html>