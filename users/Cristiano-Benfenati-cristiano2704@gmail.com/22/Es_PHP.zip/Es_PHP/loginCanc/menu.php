<!DOCTYPE html>
<html>
<head>
    <title>Menu</title>
    <style type="text/css"> 
    </style>
</head>
	<body>
	<h1> Selezione </h1> <br>
		<form name="login" action="" method="post">
			<fieldset>
				<legend>Selezione</legend>

				<?php
					$nick=$_REQUEST["ut"];
					echo "Buongiorno $nick, vuoi cancellare il tuo utente? <br>";

					echo "<a href='cancellazione.php?ut=$nick'> Si </a><br>";
					echo "<a href='#'> No </a><br>";
				?>
					
		</form>
	</body>
</html>
