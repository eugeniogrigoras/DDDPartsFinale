<?php

$nick=$_REQUEST['nick'];
$psw=$_REQUEST['psw'];
$user=false;
$pass=false;

$conn=mysql_connect("localhost","root","") or die("Errore di connessione a MySQL");

	mysql_select_db("5diis") or die("Errore di connessione al Database");

	$comando="select Nick from alunni where Nick='$nick'";
	
	if (mysql_query($comando)){
			$user=true;
			$comando2="select Psw from alunni where Psw='$psw'";
			if (mysql_query($comando2)){
					$pass=true;
					echo"Alunno trovato, reindirizzamento";
					header("Location:menu.php?ut=$nick");
  					exit();
				}
				else{
					$pass=false;
					echo"alunno non trovato";
				}

		}
		else{
			$user=false;
			echo"alunno non trovato 2";
		}

	mysql_close($conn);
	
?>


