<html>
<head>
    <title>Login</title>
</head>

<body>
    <h1> Login </h1>
    <form action="elogin.php" name="fins" method="get">
         Username <input type="text" name="nick" value="" />
         Password <input type="password" name="psw" value="" />    
        <input type="submit" name="binvia" value="Conferma">
    </form>
        </body>
</html>