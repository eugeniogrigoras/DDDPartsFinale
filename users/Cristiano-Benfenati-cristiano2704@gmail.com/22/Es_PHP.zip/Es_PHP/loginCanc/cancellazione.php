<?php

$nick=$_REQUEST["ut"];

$conn=mysql_connect("localhost","root","") or
   die("Errore di connessione a Mysql");

mysql_select_db("5diis") or die ("Errore di
                        connessione al Database");

$comando="delete from alunni where Nick='$nick'";

if (mysql_query($comando))
	echo "alunno cancellato";
else
	echo "problemi";

mysql_close($conn);  
?>