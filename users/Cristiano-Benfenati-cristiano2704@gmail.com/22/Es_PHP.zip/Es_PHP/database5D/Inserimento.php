<!DOCTYPE html>
<html>
<head>
    <title>Inserimento</title>
    <style type="text/css"> 

body {
    text-align:center;
    color:black;
    background-color:#c1c1c1; 
}
h1 {
    color:blue;
} 

fieldset{
	margin-right: 30vw;
	margin-left: 30vw;
	text-align:right;
}

input.but{
	background-color: white;
	color:#blue;
	border-radius: 1vh;
	border-collapse: collapse;
	text-align:center;
}
    </style>
</head>
<body>
<h1> Iscrizione Utente </h1> <br>
<form name="fins" action="einserimento.php" method="post">
	<fieldset>
		<legend>Informazioni</legend>

		COGNOME <input type="text" name="cognome" placeholder="Cognome"/> <br>
		NOME <input type="text" name="nome" placeholder="Nome"/> <br>
		CITTA DI RESIDENZA <select name="residenza">
			<?php
				$conn=mysql_connect("localhost","root","") or die("Errore di connessione a MySQL");

				mysql_select_db("5diis") or die("Errore di connessione al Database");

				$comando="select * from citta";				

				$risultato=mysql_query($comando);

				while ($dati=mysql_fetch_assoc($risultato)) {
					echo "<option value='$dati[IDCitta]'> $dati[NomeCitta]</option>";
				}

				mysql_close($conn);
			?>
			</select>
		<br><br>	

		<input class="but" type="submit" name="binvio" value="Conferma">
		<input class="but" type="reset" name="breset" value="Svuota">
	</fieldset>
</form>
</body>
</html>
