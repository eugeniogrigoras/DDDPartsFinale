<?php

	$res=$_REQUEST["residenza"];

	$conn=mysql_connect("localhost","root","") or die("Errore di connessione a MySQL");

	mysql_select_db("banca5d") or die("Errore di connessione al Database");

	$comando="select clienti.Cognome, clienti.Nome from clienti where clienti.FKcitta=$res";

	$risultato=mysql_query($comando);

	while ($dati=mysql_fetch_assoc($risultato)) {
					echo "$dati[Cognome] "."$dati[Nome] <br>";
				}

	mysql_close($conn);

?>