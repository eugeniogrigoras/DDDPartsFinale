<?php

	$cogn=$_REQUEST["cognome"];
	$nome=$_REQUEST["nome"];
	$res=$_REQUEST["residenza"];

	$conn=mysql_connect("localhost","root","") or die("Errore di connessione a MySQL");

	mysql_select_db("5diis") or die("Errore di connessione al Database");

	$comando="insert into alunni (Cognome,Nome,FK_Citta) values('$cogn','$nome','$res')";

	echo "insert into alunni (Cognome,Nome,FK_Citta) values('$cogn','$nome','$res') <br>";

	if (mysql_query($comando,$conn))

			echo "Record Inserito";
		else
			echo "Problemi di inserimento";

	mysql_close($conn);

?>